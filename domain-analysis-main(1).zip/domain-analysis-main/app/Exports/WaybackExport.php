<?php

namespace App\Exports;

use App\Actions\ProcessDomain;
use App\Models\Project;
use Illuminate\Support\Collection;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;

class WaybackExport implements FromCollection, WithHeadings
{
    protected $project;
    protected $startingYear;
    protected $interval;

    public function __construct(Project $project, int $startingYear, int $interval)
    {
        $this->project = $project;
        $this->startingYear = $startingYear;
        $this->interval = $interval;
    }

    public function headings(): array
    {
        return [
            'Domain',
            'Timestamp',
            'Status',
            'Archive URL',
        ];
    }

    /**
    * @return \Illuminate\Support\Collection
    */
    public function collection()
    {
        $results = new Collection;
        foreach ($this->project->domains as $domain) {
            $processed = ProcessDomain::run($domain, $this->startingYear, $this->interval, true);
            if($processed === null) {
                $results->push([
                    'domain'        => $domain->url,
                    'timestamp'     => null,
                    'status'        => 500,
                    'archive_url'   => 'Site could not be scraped - Wayback Machine returned an error',
                ]);
            } else {
                foreach ($processed as $record) {
                    $results->push([
                        'domain'        => $domain->url,
                        'timestamp'     => $record['timestamp']->format('Y-m-d H:i:s'),
                        'status'        => $record['statuscode'],
                        'archive_url'   => $record['wb_url'],
                    ]);
                }
            }
        }

        return $results;
    }
}

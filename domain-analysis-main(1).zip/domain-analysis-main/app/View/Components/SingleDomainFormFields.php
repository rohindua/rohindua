<?php

namespace App\View\Components;

use Illuminate\View\Component;

class SingleDomainFormFields extends Component
{
    public $domain;
    /**
     * Create a new component instance.
     *
     * @return void
     */
    public function __construct($domain = null)
    {
        $this->domain = $domain;
    }

    /**
     * Get the view / contents that represent the component.
     *
     * @return \Illuminate\Contracts\View\View|\Closure|string
     */
    public function render()
    {
        return view('components.forms.single-domain-form-fields');
    }
}

<?php

namespace App\View\Components;

use Illuminate\View\Component;

class ActionLink extends Component
{
    public $icon;
    public $id;
    public $tooltip;
    public $href;
    public $onclick;
    public $color;

    /**
     * Create a new component instance.
     *
     * @return void
     */
    public function __construct($icon, $id, $href = null, $onclick = null, $tooltip = null, $color = 'gray')
    {
        $this->icon = $icon;
        $this->id = $id;
        $this->tooltip = $tooltip;
        $this->href = $href;
        $this->onclick = $onclick;
        $this->color = $color;
    }

    /**
     * Get the view / contents that represent the component.
     *
     * @return \Illuminate\Contracts\View\View|\Closure|string
     */
    public function render()
    {
        return view('components.action-link');
    }
}

<?php

namespace App\View\Components;

use Illuminate\View\Component;

class KeywordCollectionList extends Component
{
    public $title;
    public $collections;

    /**
     * Create a new component instance.
     *
     * @return void
     */
    public function __construct($title, $collections)
    {
        $this->title = $title;
        $this->collections = $collections;
    }

    /**
     * Get the view / contents that represent the component.
     *
     * @return \Illuminate\Contracts\View\View|\Closure|string
     */
    public function render()
    {
        return view('components.sections.keyword-collection-list');
    }
}

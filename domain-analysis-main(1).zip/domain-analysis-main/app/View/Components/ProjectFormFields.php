<?php

namespace App\View\Components;

use Illuminate\View\Component;

class ProjectFormFields extends Component
{
    public $project;
    public $hidedomainlist;

    /**
     * Create a new component instance.
     *
     * @return void
     */
    public function __construct($project = null, $hidedomainlist = false)
    {
        $this->project = $project;
        $this->hidedomainlist = $hidedomainlist;
    }

    /**
     * Get the view / contents that represent the component.
     *
     * @return \Illuminate\Contracts\View\View|\Closure|string
     */
    public function render()
    {
        return view('components.forms.project-form-fields');
    }
}

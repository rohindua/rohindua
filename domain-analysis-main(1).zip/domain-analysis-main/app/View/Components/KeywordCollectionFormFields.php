<?php

namespace App\View\Components;

use Illuminate\View\Component;

class KeywordCollectionFormFields extends Component
{
    public $keywordcollection;
    public $hidekeywordlist;

    /**
     * Create a new component instance.
     *
     * @return void
     */
    public function __construct($keywordcollection = null, $hidekeywordlist = false)
    {
        $this->keywordcollection = $keywordcollection;
        $this->hidekeywordlist = $hidekeywordlist;
    }

    /**
     * Get the view / contents that represent the component.
     *
     * @return \Illuminate\Contracts\View\View|\Closure|string
     */
    public function render()
    {
        return view('components.forms.keyword-collection-form-fields');
    }
}

<?php

namespace App\View\Components;

use Illuminate\View\Component;

class KeywordCollectionTable extends Component
{
    public $collections;
    public $small;

    /**
     * Create a new component instance.
     *
     * @return void
     */
    public function __construct($collections, $small = false)
    {
        $this->collections = $collections;
        $this->small = $small;
    }

    /**
     * Get the view / contents that represent the component.
     *
     * @return \Illuminate\Contracts\View\View|\Closure|string
     */
    public function render()
    {
        return view('components.tables.keyword-collection-table');
    }
}

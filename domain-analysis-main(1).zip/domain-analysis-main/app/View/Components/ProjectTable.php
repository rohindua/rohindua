<?php

namespace App\View\Components;

use Illuminate\View\Component;

class ProjectTable extends Component
{
    public $projects;
    public $small;

    /**
     * Create a new component instance.
     *
     * @return void
     */
    public function __construct($projects, $small = false)
    {
        $this->projects = $projects;
        $this->small = $small;
    }

    /**
     * Get the view / contents that represent the component.
     *
     * @return \Illuminate\Contracts\View\View|\Closure|string
     */
    public function render()
    {
        return view('components.tables.project-table');
    }
}

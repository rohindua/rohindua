<?php

namespace App\View\Components;

use Illuminate\View\Component;

class ScreenshotTable extends Component
{
    public $screenshots;
    public $small;

    /**
     * Create a new component instance.
     *
     * @return void
     */
    public function __construct($screenshots, $small = false)
    {
        $this->screenshots = $screenshots;
        $this->small = $small;
    }

    /**
     * Get the view / contents that represent the component.
     *
     * @return \Illuminate\Contracts\View\View|\Closure|string
     */
    public function render()
    {
        return view('components.tables.screenshot-table');
    }
}

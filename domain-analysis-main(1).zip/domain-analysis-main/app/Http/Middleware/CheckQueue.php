<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class CheckQueue
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle(Request $request, Closure $next)
    {
        $jobCount = DB::table('jobs')
            ->where('queue', '!=', 'delete')
            ->count();
        if($jobCount > 0) {
            session()->flash('flash.banner', trans_choice('Currently processing :count snapshot|Currently processing :count snapshots', $jobCount));
            session()->flash('flash.bannerStyle', 'info');
        }
        return $next($request);
    }
}

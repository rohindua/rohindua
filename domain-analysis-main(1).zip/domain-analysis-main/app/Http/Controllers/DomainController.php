<?php

namespace App\Http\Controllers;

use App\Models\Domain;
use App\Models\Screenshot;
use Illuminate\Http\Request;

class DomainController extends Controller
{
    public function view(Request $request, $id)
    {
        $domain = Domain::find($id);

        $screenshots = Screenshot::where('domain_id', $id)
            ->with('keywords.keyword_collection')
            ->orderByDesc('snapshot_date')
            ->paginate(15);

        return view('pages.domain', [
            'domain'        => $domain,
            'screenshots'   => $screenshots,
        ]);
    }
}

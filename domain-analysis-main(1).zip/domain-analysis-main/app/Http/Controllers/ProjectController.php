<?php

namespace App\Http\Controllers;

use App\Exports\WaybackExport;
use App\Jobs\DeleteScreenshot;
use App\Jobs\ProcessSingleDomain;
use App\Models\Domain;
use App\Models\Project;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Collection;
use Illuminate\Support\Str;
use Maatwebsite\Excel\Facades\Excel;

class ProjectController extends Controller
{
    public function index()
    {
        return view('pages.dashboard', [
            'projects'      => Project::withCount(['domains', 'screenshots'])->orderByDesc('updated_at')->paginate(15),
        ]);
    }

    public function view(Request $request, $id)
    {
        $project = Project::find($id);

        if(!$project) {
            abort(404);
        }

        $domains = null;

        if($request->has('q')) {
            $domains = Domain::where('project_id', $id)->where('url', 'like', '%' . $request->input('q') . '%')->orderBy('created_at', 'asc')->orderBy('url')->with(['screenshots' => function($query) {
                $query->orderBy('snapshot_date', 'asc');
            }])->paginate(100);
        } else {
            $domains = Domain::where('project_id', $id)->orderBy('created_at', 'asc')->orderBy('url')->with(['screenshots' => function($query) {
                $query->orderBy('snapshot_date', 'asc');
            }])->paginate(100);
        }

        return view('pages.project', [
            'project'      => $project,
            'domains'      => $domains,
        ]);
    }

    public function create(Request $request)
    {
        $validated = $request->validate([
            'project-name'          => 'required|string|max:255',
            'project-description'   => 'nullable|string',
            'project-domains'       => 'required|string',
        ]);

        $existing = Project::where('name', trim($request->input('project-name')))->first();

        if($existing) {
            session()->flash('flash.banner', __('A project with this name already exists!'));
            session()->flash('flash.bannerStyle', 'danger');

            return redirect()->back();
        }
        
        $project = new Project;
        $project->name = trim($request->input('project-name'));
        $project->description = $request->input('project-description');
        $project->save();

        $domainInput = preg_split("/\r\n|\n|\r/", $request->input('project-domains'));
        $domains = array();
        
        foreach ($domainInput as $d) {
            $domains[] = array(
                'url'           => $d,
                'project_id'    => $project->id,
                'created_at'    => Carbon::now(),
                'updated_at'    => Carbon::now(),
            );
        }

        $screenshots = [];

        foreach ($domains as $domain) {
            $d = Domain::where('url', $domain['url'])->first();
            $newDomain = Domain::create($domain);
            if($d) {
                foreach ($d->screenshots as $screenshot) {
                    $newScreenshot = $screenshot->replicate();
                    $newScreenshot->domain_id = $newDomain->id;
                    $newScreenshot->save();
                }
            }
        }

        session()->flash('flash.banner', __('Project successfully created!'));
        session()->flash('flash.bannerStyle', 'success');

        return redirect()->back();
    }

    public function edit(Request $request)
    {
        $validated = $request->validate([
            'project-id'            => 'required|exists:projects,id',
            'project-name'          => 'required|unique:projects,name|string|max:255',
            'project-description'   => 'nullable|string',
        ]);

        $project = Project::find($request->input('project-id'));
        $project->name = $request->input('project-name');
        $project->description = $request->input('project-description');
        $project->save();

        session()->flash('flash.banner', __('Project updated created!'));
        session()->flash('flash.bannerStyle', 'success');

        return redirect()->back();
    }

    public function delete(Request $request)
    {
        $project = Project::find($request->input('project-id'));
        if(!$project) {
            session()->flash('flash.banner', __('Error while deleting project: a project with this ID does not exist.'));
            session()->flash('flash.bannerStyle', 'danger');
            return redirect()->back();
        }

        $project->load('domains');

        foreach ($project->domains as $domain) {
            foreach ($domain->screenshots as $screenshot) {
                $file = explode('/', $screenshot->url);
                $filename = end($file);
                DeleteScreenshot::dispatch($filename)->onQueue('delete');
                $screenshot->forceDelete();
            }
            $domain->forceDelete();
        }
        
        $project->forceDelete();
        session()->flash('flash.banner', __('Project successfully deleted!'));
        session()->flash('flash.bannerStyle', 'success');

        return redirect()->back();
    }

    public function addDomains(Request $request, $id)
    {
        $validated = $request->validate([
            'project-domains'       => 'required|string',
        ]);

        $project = Project::find($id);
        if(!$project) {
            session()->flash('flash.banner', __('Error while adding domain: a project with this ID does not exist.'));
            session()->flash('flash.bannerStyle', 'danger');
            return redirect()->back();
        }

        $domainInput = preg_split("/\r\n|\n|\r/", $request->input('project-domains'));
        $domains = array();
        
        foreach ($domainInput as $d) {
            $domains[] = array(
                'url'           => $d,
                'project_id'    => $project->id,
                'created_at'    => Carbon::now(),
                'updated_at'    => Carbon::now(),
            );
        }

        $screenshots = [];

        foreach ($domains as $domain) {
            $d = Domain::where('url', $domain['url'])->first();
            $newDomain = Domain::create($domain);
            if($d) {
                foreach ($d->screenshots as $screenshot) {
                    $newScreenshot = $screenshot->replicate();
                    $newScreenshot->domain_id = $newDomain->id;
                    $newScreenshot->save();
                }
            }
        }

        session()->flash('flash.banner', __('Domain successfully added!'));
        session()->flash('flash.bannerStyle', 'success');

        return redirect()->back();
    }

    public function scheduleRun(Request $request)
    {
        $validated = $request->validate([
            'id'            => 'required|exists:projects,id',
            'period'        => 'required|integer',
            'starting-year' => 'required|integer',
            'scraper'       => 'required|integer',
        ]);

        $project = Project::find($request->input('id'));
        $project->processing_interval = $request->input('period');
        $project->save();

        if($request->has('export') && $request->input('export') == 'yes') {
            $filename = Carbon::now()->format('Ymd') . '-' . Str::slug($project->name) . '-archive-urls.csv';
            $exporter = new WaybackExport($project, intval($request->input('starting-year')), intval($request->input('period')));
            return Excel::download($exporter, $filename, \Maatwebsite\Excel\Excel::CSV, [
                'Content-Type' => 'text/csv',
            ]);
        }

        $domains = Domain::where('project_id', $project->id)->orderBy('url')->get();

        $queueName = config('queue.scraping.domainqueue');
        foreach($domains as $domain) {
            ProcessSingleDomain::dispatch($domain, intval($request->input('starting-year')), intval($request->input('period')), intval($request->input('scraper')))->onQueue($queueName);
        }

        session()->flash('flash.banner', __('Processing scheduled! Please wait for it to complete in the background (refresh to see new screenshots).'));
        session()->flash('flash.bannerStyle', 'success');

        return redirect()->back();
    }

    public function getProjectForm(Request $request, $id)
    {
        $project = Project::find($id);

        return view('components.forms.project-form-fields', [
            'project'           => $project,
            'hidedomainlist'    => true,
        ]);
    }
}

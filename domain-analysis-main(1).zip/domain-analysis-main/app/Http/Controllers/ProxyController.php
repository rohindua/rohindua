<?php

namespace App\Http\Controllers;

use App\Models\Proxy;
use Carbon\Carbon;
use Illuminate\Http\Request;

class ProxyController extends Controller
{
    public function index()
    {
        return view('pages.proxies', [
            'proxies'       => Proxy::all(),
        ]);
    }

    public function save(Request $request)
    {
        Proxy::query()->delete();
        if($request->input('proxies')) {
            $proxyInput = preg_split("/\r\n|\n|\r/", trim($request->input('proxies')));
            $proxies = array();
            
            foreach ($proxyInput as $p) {
                $proxy = explode(':', $p);
                $proxies[] = array(
                    'proxy_url'     => $proxy[0],
                    'port'          => $proxy[1],
                    'user'          => $proxy[2],
                    'password'      => $proxy[3],
                    'created_at'    => Carbon::now(),
                    'updated_at'    => Carbon::now(),
                );
            }

            Proxy::insert($proxies);
        }

        session()->flash('flash.banner', __('Proxy list successfully updated!'));
        session()->flash('flash.bannerStyle', 'success');

        return redirect()->back();
    }
}

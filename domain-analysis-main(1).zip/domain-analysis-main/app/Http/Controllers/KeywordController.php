<?php

namespace App\Http\Controllers;

use App\Models\Keyword;
use App\Models\KeywordCollection;
use Carbon\Carbon;
use Illuminate\Http\Request;

class KeywordController extends Controller
{
    public function index()
    {
        return view('pages.keywords', [
            'collections'      => KeywordCollection::withCount('keywords')->paginate(30),
        ]);
    }

    public function getKeywords(Request $request, $id)
    {
        $collection = KeywordCollection::find($id);
        $keywords = Keyword::where('keyword_collection_id', $id)->paginate(150);
        return view('pages.keyword', [
            'collection'       => $collection,
            'keywords'         => $keywords,
        ]);
    }

    public function addKeyword(Request $request, $id)
    {
        $validated = $request->validate([
            'keyword'               => 'required|string|unique:keywords,name|max:255',
        ]);

        $keyword = new Keyword;
        $keyword->name = $validated['keyword'];
        $keyword->keyword_collection_id = $id;
        $keyword->save();

        session()->flash('flash.banner', __('Keyword successfully added!'));
        session()->flash('flash.bannerStyle', 'success');

        return redirect()->back();
    }

    public function deleteKeyword(Request $request)
    {
        $validated = $request->validate([
            'keyword-id'            => 'required|exists:keywords,id',
        ]);

        $keyword = Keyword::find($validated['keyword-id']);
        $keyword->delete();

        session()->flash('flash.banner', __('Keyword successfully deleted!'));
        session()->flash('flash.bannerStyle', 'success');

        return redirect()->back();
    }

    public function createCollection(Request $request)
    {
        $validated = $request->validate([
            'collection-name'       => 'required|string|max:255',
            'collection-color'      => 'required|string|max:20',
            'collection-keywords'   => 'required|string',
        ]);

        $collection = new KeywordCollection;
        $collection->name = $request->input('collection-name');
        $collection->color = $request->input('collection-color');
        $collection->save();

        $keywordsInput = preg_split("/\r\n|\n|\r/", $request->input('collection-keywords'));
        $keywords = array();
        
        foreach ($keywordsInput as $keyword) {
            $keywords[] = array(
                'name'                  => $keyword,
                'keyword_collection_id' => $collection->id,
                'created_at'            => Carbon::now(),
                'updated_at'            => Carbon::now(),
            );
        }

        Keyword::insert($keywords);

        session()->flash('flash.banner', __('Collection successfully created!'));
        session()->flash('flash.bannerStyle', 'success');

        return redirect()->back();
    }

    public function deleteCollection(Request $request)
    {
        $collection = KeywordCollection::find($request->input('collection-id'));
        if(!$collection) {
            session()->flash('flash.banner', __('Error while deleting keyword collection: a collection with this ID does not exist.'));
            session()->flash('flash.bannerStyle', 'danger');
            return redirect()->back();
        }

        $keywords = Keyword::where('keyword_collection_id', $collection->id)->forceDelete();
        $collection->forceDelete();

        session()->flash('flash.banner', __('Keyword collection successfully deleted!'));
        session()->flash('flash.bannerStyle', 'success');

        return redirect()->back();
    }
}

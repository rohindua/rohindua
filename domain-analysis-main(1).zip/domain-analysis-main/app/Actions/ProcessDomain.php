<?php

namespace App\Actions;

use App\Jobs\TakeScreenshot;
use App\Models\Domain;
use App\Models\KeywordCollection;
use App\Models\Proxy;
use App\Models\Screenshot;
use Carbon\Carbon;
use Carbon\CarbonImmutable;
use GuzzleHttp\Client;
use GuzzleHttp\TransferStats;
use Lorisleiva\Actions\Concerns\AsAction;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Bus;

class ProcessDomain
{
    use AsAction;

    private $endpoint = "https://web.archive.org/";
    private $domain;
    private $proxies;
    private $proxyIndex = 0;
    private $queueNum = 2;
    private $startingYear;
    private $scraper;

    public function handle(Domain $domain, int $startingYear, int $interval = 6, bool $returnTimemap = false, int $scraper = 0)
    {
        $single = ($interval === -1);
        $this->domain = $domain;
        $this->startingYear = $startingYear;
        $this->scraper = $scraper;
        $client = new Client(['base_uri' => $this->endpoint]);
        $this->proxies = Proxy::where('is_enabled', true)->get();
        try {
            $timemap = $this->getTimeMap($this->domain->url, $client, $single);
            $timemap = $this->filterTimeMap($timemap, $interval, $single);
            if($returnTimemap) {
                return $timemap;
            }
            $this->scrape($timemap, $client);
        } catch (\Throwable $th) {
            throw $th;
        }
    }

    private function isAvailable($url, $client)
    {
        $res = $client->request('GET', '/wayback/available', [
            'query'     => ['url' => $url],
            'stream'    => true,
        ])->getBody()->getContents();

        $res = json_decode($res);
        if(!empty($res->archived_snapshots) && !empty($res->archived_snapshots->closest)) {
            return $res->archived_snapshots->closest->available;
        }
        return false;
    }

    private function getTimeMap($url, $client, $single = false)
    {
        $res = Cache::remember('timemap-' . $url, 300, function () use (&$client, &$url, &$single) {
            $collapse = $single ? '1' : '6'; // either collapse results into a single result or monthly results
            $properties = [
                'query' => [
                    'url'       => $url,
                    'output'    => 'json',
                    'collapse'  => 'timestamp:' . $collapse, // only get monthly results
                    'from'      => $this->startingYear,
                ],
            ];
            if(count($this->proxies) > 0) {
                $this->proxyIndex = array_rand($this->proxies->toArray());
                $proxy = $this->proxies[$this->proxyIndex];
                $properties['proxy'] = 'http://' . $proxy->user . ':' . $proxy->password . '@' . $proxy->proxy_url . ':' . $proxy->port;
            }
            return $client->request('GET', '/cdx/search/cdx', $properties)->getBody()->getContents();
        });

        // strip string from characters conflicting with json decoding - does not affect the actual data
        $res = preg_replace('/[\x00-\x1F\x80-\xFF]/', '', $res);
        $res = json_decode($res, true);

        // generate associative array for ease of use
        $timemap = array();
        for ($i = 1; $i < count($res); $i++) {
            $record = array();
            foreach ($res[0] as $colNum => $key) {
                $record[$key] = $res[$i][$colNum];
            }
            // generate an url to archive.org for later convenience
            $record['wb_url'] = $this->endpoint . 'web/' . $record['timestamp'] . 'if_/' . $record['original'];
            // convert timestamp into immutable carbon object
            $record['timestamp'] = CarbonImmutable::createFromFormat('YmdHis', $record['timestamp']);
            $timemap[] = collect($record);
        }

        // return a sorted eloquent collection
        return collect($timemap)->sortByDesc('timestamp');
    }

    private function filterTimeMap($timemap, $interval, $single = false)
    {
        $filteredTimemap = array();
        $nextDate = null;

        foreach ($timemap as $item) {
            $timestamp = $item['timestamp'];
            if($single) {
                $filteredTimemap[] = $item;
                break;
            }
            // check if timestamp exceeds date
            if($nextDate === null ||$timestamp <= $nextDate) {
                // subtract [interval] months from timestamp for new reference date
                $nextDate = $timestamp->subMonths($interval);
                $filteredTimemap[] = $item;
            }
        }
        
        return collect($filteredTimemap);
    }

    private function scrape($timemap, $client)
    {
        $idx = 0;
        $max = intval(config('queue.scraping.workers'));
        $queueName = config('queue.scraping.screenshotqueue');
        foreach ($timemap as $item) {
            TakeScreenshot::dispatch($this->domain, $item, $this->scraper)->onQueue($queueName . $idx);
            $idx++;
            if($idx >= $max) {
                $idx = 0;
            }
        }
    }
}

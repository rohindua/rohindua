<?php

namespace App\Actions;

use App\Jobs\TakeOneSimpleApiScreenshot;
use App\Jobs\TakeThrumScreenshotJob;
use App\Models\Domain;
use App\Models\Proxy;
use App\Models\KeywordCollection;
use App\Models\Screenshot;
use GuzzleHttp\Client;
use Carbon\CarbonImmutable;
use Lorisleiva\Actions\Concerns\AsAction;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Storage;

class TakeScreenshot
{
    use AsAction;

    private $endpoint = "https://web.archive.org/";
    private $domain;
    private $proxies;
    private $proxyIndex = 0;
    private $scraper;

    public function handle($domain, $item, $scraper)
    {
        $this->domain = $domain;
        $this->scraper = $scraper;
        $this->proxies = Proxy::where('is_enabled', true)->get();
        $client = new Client(['base_uri' => $this->endpoint]);

        $this->scrapePage($item, $client);
    }

    private function scrapePage($item, $client)
    {
        $pageBody = $client->request('GET', $item['wb_url'])->getBody()->getContents();

        // collect an array of keywords from the page
        $keywordIds = array();
        $keywordCollections = KeywordCollection::with('keywords')->get();
        foreach($keywordCollections as $keywordCollection) {
            foreach($keywordCollection->keywords as $keyword) {
                // check if the keyword is in the page
                if(strpos($pageBody, $keyword->name) !== false) {
                    $keywordIds[] = $keyword->id;
                }
            }
        }
        $this->takeScreenshot($item, $keywordIds);
    }

    private function takeScreenshot($item, $keywordIds)
    {
        $url = $item['wb_url'];
        $existing = Screenshot::where('archive_org_url', $url)->first();
        if($existing) {
            if($this->domain->id !== $existing->domain_id) {
                $new = $existing->replicate();
                $new->domain_id = $this->domain->id;
                $new->save();
                return $new;
            }

            return $existing;
        }
        
        $max = intval(config('queue.scraping.workers'));
        $queueName = config('queue.scraping.screenshotqueue');
        if($this->scraper === 1) {
            return TakeOneSimpleApiScreenshot::dispatch($this->domain, $item, $keywordIds)->onQueue($queueName . random_int(0, $max - 1));
        } else if ($this->scraper === 2) {
            return TakeThrumScreenshotJob::dispatch($this->domain, $item, $keywordIds)->onQueue($queueName . random_int(0, $max - 1));
        } else {
            return $this->getSiteShotScreenshot($url, $item, $keywordIds);
        }
    }

    private function getSiteShotScreenshot($url, $item, $keywordIds)
    {
        $userAgent = \Campo\UserAgent::random([
            'os_type' => ['Windows', 'MacOS', 'Linux'],
            'device_type' => 'Desktop',
        ]);
        $res = Cache::remember('ss-' . $url, 300, function () use ($userAgent, &$url) {
            $query = [
                'url'               => $url,
                'userkey'           => config('services.siteshot.userkey'),
                'full_size'         => true,
                'scaled_width'      => 800,
                'height'            => 600,
                'user_agent'        => $userAgent,
                'response_type'     => 'json',
                'delay_time'        => 7000,
            ];
            if(count($this->proxies) > 0) {
                $this->proxyIndex = array_rand($this->proxies->toArray());
                $proxy = $this->proxies[$this->proxyIndex];
                $query['http_proxy'] = $proxy->proxy_url . ':' . $proxy->port;
                $query['proxy_username'] = $proxy->user;
                $query['proxy_password'] = $proxy->password;
            }
            $client = new Client(['base_uri' => config('services.siteshot.baseurl')]);
            return $client->request('GET', '/', [
                'query' => $query,
            ])->getBody()->getContents();
        });

        $res = json_decode($res, true);
        $screenshot = new Screenshot;
        if($res['response'] && $res['response']['status_code'] === 200) {
            $screenshot->url = Storage::disk('s3')->url($this->processImage($res['image']));
        } else {
            $screenshot->url = '';
        }
        $screenshot->domain_id = $this->domain->id;
        $screenshot->archive_org_url = $url;
        $screenshot->status = isset($res['response']['status_code']) ? $res['response']['status_code'] : 500;
        $screenshot->user_agent = $userAgent;
        $screenshot->digest = $item['digest'];
        $screenshot->snapshot_date = $item['timestamp'];
        $screenshot->save();
        $screenshot->keywords()->sync($keywordIds);
        return $screenshot;
    }

    private function processImage($base64Image)
    {
        // get the extension from the base64 string
        $extension = explode('/', explode(':', substr($base64Image, 0, strpos($base64Image, ';')))[1])[1];

        // remove leading information from the base64 string
        $replace = substr($base64Image, 0, strpos($base64Image, ',') + 1); 
        $img = str_replace($replace, '', $base64Image); 

        // replace spaces with + in the base64 string
        $img = str_replace(' ', '+', $img); 
       
        // generate a filename
        $filename = 'ss' . time() . '-' . random_int(10000000, 99999999) . '.' . $extension;

        // save the image to S3
        Storage::disk('s3')->put($filename, base64_decode($img));

        return $filename;
    }
}

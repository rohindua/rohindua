<?php

namespace App\Actions;

use App\Models\Domain;
use App\Models\Screenshot;
use GuzzleHttp\Client;
use Illuminate\Support\Facades\Storage;
use Lorisleiva\Actions\Concerns\AsAction;

class TakeOneSimpleApiScreenshot
{
    use AsAction;

    private $baseUrl = 'https://onesimpleapi.com';

    public function handle(Domain $domain, $item, $keywordIds)
    {
        try {
            return $this->getScreenshot($domain, $item, $keywordIds);
        } catch (\Throwable $th) {
            throw $th;
        }
    }
    private function getScreenshot(Domain $domain, $item, $keywordIds)
    {
        $client = new Client(['base_uri' => $this->baseUrl]);
        $url = $item['wb_url'];
        $query = [
            'url'               => $url,
            'token'             => config('services.onesimpleapi.api_key'),
            'output'            => 'json',
            'screen'            => 'custom:1920x1080',
            'full'              => 'yes',
        ];

        $response = $client->request('GET', '/api/screenshot', [
            'query' => $query,
        ])->getBody()->getContents();
        $response = json_decode($response, true);

        $client = new Client([]);
        $image = $client->request('GET', $response['url'])->getBody()->getContents();

        $path = parse_url($response['url'], PHP_URL_PATH);
        $extension = pathinfo($path, PATHINFO_EXTENSION);
        $filename = 'osa' . time() . '-' . random_int(10000000, 99999999) . '.' . $extension;

        Storage::disk('s3')->put($filename, $image);

        $screenshot = new Screenshot;
        $screenshot->url = Storage::disk('s3')->url($filename);
        $screenshot->domain_id = $domain->id;
        $screenshot->archive_org_url = $url;
        $screenshot->status = 200;
        $screenshot->digest = $item['digest'];
        $screenshot->snapshot_date = $item['timestamp'];
        $screenshot->save();
        $screenshot->keywords()->sync($keywordIds);
        return $screenshot;
    }
}

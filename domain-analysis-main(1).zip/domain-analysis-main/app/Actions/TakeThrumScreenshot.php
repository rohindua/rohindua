<?php

namespace App\Actions;

use App\Jobs\TakeThrumScreenshotJob;
use App\Models\Domain;
use App\Models\Screenshot;
use GuzzleHttp\Client;
use Illuminate\Support\Facades\Storage;
use Lorisleiva\Actions\Concerns\AsAction;

class TakeThrumScreenshot
{
    use AsAction;

    private $prefetch = false;
    private $prefetchUrl = 'http://image.thum.io/get/prefetch/width/1024/noanimate/allowJPG/fullpage';
    private $baseUrl = 'http://image.thum.io/get/width/1024/noanimate/allowJPG/fullpage';

    public function handle(Domain $domain, $item, $keywordIds)
    {
        if($this->prefetch) {
            $url = $item['wb_url'];
            $client = new Client([]);
            $response = $client->request('GET', $this->prefetchUrl . '/auth/' . config('services.thrum.api_key') . '/' . $url);
            $prefetchedResult = $response->getBody()->getContents();
    
            if(str_contains($prefetchedResult, 'is cached')) {
                return $this->getScreenshot($domain, $item, $keywordIds);
            } else {
                TakeThrumScreenshotJob::dispatch($domain, $item, $keywordIds)->delay(now()->addMinutes(7));
            }
        } else {
            return $this->getScreenshot($domain, $item, $keywordIds);
        }
    }
    private function getScreenshot(Domain $domain, $item, $keywordIds)
    {
        $client = new Client([]);
        $url = $item['wb_url'];
        $response = $client->request('GET', $this->baseUrl . '/auth/' . config('services.thrum.api_key') . '/' . $url);
        $headers = $response->getHeaders();
        $extension = $this->getExtension($headers['Content-Disposition'][0]);
        $filename = 'thr' . time() . '-' . random_int(10000000, 99999999) . '.' . $extension;
        Storage::disk('s3')->put($filename, $response->getBody()->getContents());

        $screenshot = new Screenshot;
        $screenshot->url = Storage::disk('s3')->url($filename);
        $screenshot->domain_id = $domain->id;
        $screenshot->archive_org_url = $url;
        $screenshot->status = 200;
        $screenshot->digest = $item['digest'];
        $screenshot->snapshot_date = $item['timestamp'];
        $screenshot->save();
        $screenshot->keywords()->sync($keywordIds);
        return $screenshot;
    }

    private function getExtension($contentDisposition)
    {
        if (preg_match('/.+filename=\s?"(.+)"/', $contentDisposition, $matches)) {
            $parts = explode('.', $matches[1]);
            return end($parts);
        }
        return 'jpg';
    }
}

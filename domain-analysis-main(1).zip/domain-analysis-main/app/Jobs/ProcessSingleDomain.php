<?php

namespace App\Jobs;

use App\Models\Domain;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldBeUnique;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Queue\Middleware\RateLimited;
use Illuminate\Queue\Middleware\ThrottlesExceptions;

class ProcessSingleDomain implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    /**
     * The number of times the job may be attempted.
     *
     * @var int
     */
    public $tries = 5;

    /**
     * The maximum number of unhandled exceptions to allow before failing.
     *
     * @var int
     */
    public $maxExceptions = 5;

    protected $domain;
    protected $interval;
    protected $startingYear;
    protected $scraper;

    /**
     * Create a new job instance.
     *
     * @return void
     */
    public function __construct(Domain $domain, int $startingYear = 2010, int $interval = 6, int $scraper = 0)
    {
        $this->domain = $domain;
        $this->interval = $interval;
        $this->startingYear = $startingYear;
        $this->scraper = $scraper;
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        try {
            \App\Actions\ProcessDomain::run($this->domain, $this->startingYear, $this->interval, false, $this->scraper);
        } catch (\Throwable $th) {
            throw $th;
        }
    }
}

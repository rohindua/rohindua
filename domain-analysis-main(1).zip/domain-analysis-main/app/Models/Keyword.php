<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Keyword extends Model
{
    use HasFactory;
    
    protected $fillable = [
        'name',
        'keyword_collection_id',
        'created_at',
        'updated_at',
    ];

    public function screenshots()
    {
        return $this->belongsToMany(Screenshot::class, 'keywords_screenshots');
    }

    public function keyword_collection()
    {
        return $this->belongsTo(KeywordCollection::class);
    }
}
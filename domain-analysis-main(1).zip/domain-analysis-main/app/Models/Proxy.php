<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Proxy extends Model
{
    use HasFactory;

    protected $fillable = [
        'proxy_url',
        'port',
        'user',
        'password',
        'is_enabled',
        'created_at',
        'updated_at',
    ];

    public function getFullStringAttribute()
    {
        return "{$this->proxy_url}:{$this->port}:{$this->user}:{$this->password}";
    }
}

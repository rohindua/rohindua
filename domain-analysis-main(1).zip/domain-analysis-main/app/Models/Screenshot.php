<?php

namespace App\Models;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Prunable;

class Screenshot extends Model
{
    use HasFactory;
    use Prunable;

    public function prunable()
    {
        return static::doesntHave('domain.project');
    }

    public function domain()
    {
        return $this->belongsTo(Domain::class);
    }

    public function keywords()
    {
        return $this->belongsToMany(Keyword::class, 'keywords_screenshots');
    }

    public function getSnapshotDateAttribute($snapshot_date)
    {
        return Carbon::parse($snapshot_date);
    }
}

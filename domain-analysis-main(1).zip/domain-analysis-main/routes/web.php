<?php

use App\Http\Controllers\DomainController;
use App\Http\Controllers\KeywordController;
use App\Http\Controllers\ProjectController;
use App\Http\Controllers\ProxyController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::middleware(['auth:sanctum', 'verified', 'check.queue'])->group(function () {
    // Project management
    Route::get('/', [ProjectController::class, 'index'])->name('dashboard');
    Route::get('/project/{id}', [ProjectController::class, 'view']);
    Route::get('/project/{id}/form', [ProjectController::class, 'getProjectForm']);
    Route::post('/project/new', [ProjectController::class, 'create']);
    Route::post('/project/edit', [ProjectController::class, 'edit']);
    Route::post('/project/delete', [ProjectController::class, 'delete']);
    Route::post('/project/{id}/add', [ProjectController::class, 'addDomains']);
    Route::post('/project/run', [ProjectController::class, 'scheduleRun']);

    // Proxy management
    Route::get('/proxies', [ProxyController::class, 'index'])->name('proxies');
    Route::post('/proxies/save', [ProxyController::class, 'save']);

    // Keywords management
    Route::get('/keywords', [KeywordController::class, 'index'])->name('keywords');
    Route::get('/keywords/{id}', [KeywordController::class, 'getKeywords']);
    Route::post('/keyword-collection/new', [KeywordController::class, 'createCollection']);
    Route::post('/keyword-collection/delete', [KeywordController::class, 'deleteCollection']);
    Route::post('/keyword/{id}/new', [KeywordController::class, 'addKeyword']);
    Route::post('/keyword/delete', [KeywordController::class, 'deleteKeyword']);

    // Domain management
    Route::get('/domain/{id}', [DomainController::class, 'view']);
});
<span
    style="line-height:1.2rem"
    class="whitespace-nowrap bg-{{ $color }}-200 text-{{ $color }}-600 h-5 py-0 px-2 cursor-default rounded-full text-xs ml-1"
    @if($tooltip)
    data-microtip-position="top" 
    role="tooltip" 
    aria-label="{{ $tooltip }}"
    @endif >
    @if(empty($slot))
        {{ __('None') }}
    @else
        {{ $slot }}
    @endif
</span>
<a  id="{{ $id }}"
    @if($href) href="{{ $href }}" 
    @else href=# @endif
    @if($onclick) onclick="{{ $onclick }}" @endif
    class="inline-block py-1 px-1 w-auto bg-{{ $color }}-100 hover:bg-{{ $color }}-300 focus:ring-{{ $color }}-300 
           focus:ring-offset-{{ $color }}-100 text-{{ $color }}-300 visited:text-{{ $color }}-300 hover:text-{{ $color }}-500 
           transition ease-in duration-200 text-center text-base font-semibold shadow-md focus:outline-none focus:ring-2 
           focus:ring-offset-2 rounded-lg cursor-pointer"
    @if($tooltip)
    data-microtip-position="top" 
    role="tooltip" 
    aria-label="{{ $tooltip }}"
    @endif >
    <x-icon type="{{ $icon }}" class="h-4 w-4" />
</a>
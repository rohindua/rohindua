<div class="flex flex-col w-64 px-4 py-8 bg-white border-r dark:bg-gray-800 dark:border-gray-600">
    <x-section-title>{{ __('Admin Dashboard') }}</x-section-title>
    <div class="flex flex-col justify-between flex-1">
        <nav>
            <x-side-bar-nav-link href="{{ route('dashboard') }}" :active="request()->routeIs('dashboard')">
                <x-slot name="icon">
                    <x-icon type="camera" class="h-5 w-5"></x-icon>
                </x-slot>
                {{ __('Dashboard') }}
            </x-side-bar-nav-link>
            <x-side-bar-nav-link href="{{ route('keywords') }}" :active="request()->routeIs('keywords')">
                <x-slot name="icon">
                    <x-icon type="clipboard-list" class="h-5 w-5"></x-icon>
                </x-slot>
                {{ __('Keywords') }}
            </x-side-bar-nav-link>
            <x-side-bar-nav-link href="{{ route('proxies') }}" :active="request()->routeIs('proxies')">
                <x-slot name="icon">
                    <x-icon type="shield-exclamation" class="h-5 w-5"></x-icon>
                </x-slot>
                {{ __('Proxies') }}
            </x-side-bar-nav-link>
        </nav>
        <div class="items-center px-4 -mx-2">
            <hr class="my-6 dark:border-gray-600" />
            <div class="flex justify-between">
                <div class="font-medium text-base text-gray-800">{{ Auth::user()->name }}</div>
                <form class="font-medium text-sm text-gray-500 hover:text-gray-700" method="POST" action="{{ route('logout') }}">
                    @csrf
                    <a href="{{ route('logout') }}" onclick="event.preventDefault();this.closest('form').submit();">
                        {{ __('Log Out') }}
                    </a>
                </form>
            </div>
            <div class="w-100 font-medium text-sm text-gray-500">{{ Auth::user()->email }}</div>
        </div>
    </div>
</div>
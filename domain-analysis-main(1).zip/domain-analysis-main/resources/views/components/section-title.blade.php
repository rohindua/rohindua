<div class="relative">
    <div class="absolute inset-0 flex items-center">
        <div class="w-full border-t border-gray-300"></div>
    </div>
    <div class="relative flex justify-center text-lg leading-5">
        <span class="px-2 text-gray-500 bg-white all-small-caps">
            {{ $slot }}
        </span>
    </div>
</div>
@forelse ($domains as $domain)
    <x-screenshot-list title="{{ $domain->url }}" :screenshots="$domain->screenshots" />
@empty
    <p>{{ __('No domains found') }}</p>
@endforelse
<div class="w-full">
    {{ $domains->withQueryString()->onEachSide(5)->links('pagination') }}
</div>
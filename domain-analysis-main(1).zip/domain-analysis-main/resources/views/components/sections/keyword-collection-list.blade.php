<div class="w-full px-2">
    <div class="w-full py-8 pb-1 px-4 sm:px-6 lg:px-8">
        <x-section-title>{{ $title }}</x-section-title>
    </div>
</div>
<div class="mx-7 my-6">
    <x-keyword-collection-table :collections="$collections" />
</div>
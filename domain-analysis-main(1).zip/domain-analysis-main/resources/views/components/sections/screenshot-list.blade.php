<div class="w-full px-2">
    <div class="w-full py-8 pb-1 px-4 sm:px-6 lg:px-8">
        <x-section-title>{{ $title }}</x-section-title>
    </div>
</div>
<div class="mx-7 my-6 grid sm:grid-cols-2 md:grid-cols-4 lg:grid-cols-6 xl:grid-cols-8 2xl:grid-cols-10 gap-4">
    @forelse ($screenshots as $screenshot)
        <div id="ss-{{ $screenshot->id }}" class="col-span-2 mg-white group relative rounded-lg shadow-lg hover:shadow-2xl transform duration-200">
            <div class="relative w-full h-80 md:h-64 lg:h-44">
                @if($screenshot->status === 200)
                <img src="{{ $screenshot->url }}"
                    loading="lazy"
                    data-featherlight="{{ $screenshot->url }}"
                    data-featherlight-after-content="DomainAnalysis.loadImageZoom()"
                    class="w-full h-full object-center object-cover rounded-t-lg cursor-pointer lazy">
                @else
                <div class="w-full h-full object-center object-cover bg-red-200 text-red-500 flex flex-col justify-center items-center">
                    <x-icon type="exclamation-circle" class="h-20 w-20 mb-2"></x-icon>
                    <p class="text-lg uppercase">"{{ $screenshot->status }}"</p>
                    <p class="text-xs uppercase">{{ __('Error when taking screenshot') }}</p>
                </div>
                @endif
            </div>
            <div class="px-3 py-4">
                <div class="flex justify-between items-center">
                    <h3 class="text-lg text-gray-500 font-bold">{{ $screenshot->snapshot_date->format('Y - m - d') }}</h3>
                    <a href="{{ $screenshot->archive_org_url }}" target="_blank" class="text-xs">{{ __('archive.org') }}</a>
                </div>
                @forelse ($screenshot->keywords as $keyword)
                    <x-pill tooltip="{{ $keyword->keyword_collection->name }} {{ __('keyword') }}" color="{{ $keyword->keyword_collection->color }}">{{ strtolower($keyword->name) }}</x-pill>
                @empty
                    <p class="text-gray-400">{{ __('No keywords found') }}</p>
                @endforelse                
            </div>
        </div>
    @empty
        <p class="text-gray-400 col-span-12">{{ __('No screenshots yet') }}</p>
    @endforelse
</div>
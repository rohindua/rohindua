<x-text-input name="collection-name" value="{{ $keywordcollection ? $keywordcollection->name : '' }}" id="collection-name" placeholder="{{ __('Collection name') }}" maxlength=255 required="required" class="mb-4" />
<x-color-select name="collection-color" id="collection-color" />
@if(!$hidekeywordlist)
<x-textarea class="flex-2 mb-3 h-60" name="collection-keywords" id="collection-keywords" placeholder="{{ __('Paste a list of keywords here, one keyword per line') }}"></x-textarea>
@endif
@if($keywordcollection)
<input type="hidden" name="collection-id" @if($keywordcollection) value="{{ $keywordcollection->id }}" @endif >
@endif
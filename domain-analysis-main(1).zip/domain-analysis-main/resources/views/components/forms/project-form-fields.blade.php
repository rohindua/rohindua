<x-text-input name="project-name" value="{{ $project ? $project->name : '' }}" id="project-name" placeholder="{{ __('Project name') }}" maxlength=255 required="required" class="mb-4" />
<x-textarea class="flex-2 mb-3 h-20" name="project-description" id="project-description" placeholder="{{ __('Description (optional)') }}">@if($project){!! $project->description !!}@endif</x-textarea>
@if(!$hidedomainlist)
<x-textarea class="flex-2 mb-3 h-60" name="project-domains" id="project-domains" placeholder="{{ __('Paste a list of domains here, one domain per line') }}"></x-textarea>
@endif
@if($project)
<input type="hidden" name="project-id" @if($project) value="{{ $project->id }}" @endif >
@endif
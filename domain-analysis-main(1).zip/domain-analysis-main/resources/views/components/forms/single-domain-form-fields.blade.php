<x-text-input name="domain-url" value="{{ $domain ? $domain->url : '' }}" id="domain-url" placeholder="{{ __('Web address') }}" maxlength=255 required="required" class="mb-4" />
@if($domain)
<input type="hidden" name="domain-id" @if($domain) value="{{ $domain->id }}" @endif >
@endif
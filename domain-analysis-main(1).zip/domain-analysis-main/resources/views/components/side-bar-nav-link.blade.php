@props([
    'icon',
])
@if ($active)
    <a href="{{ $href }}" class="flex items-center px-4 py-2 mt-5 visited:text-gray-700 hover:text-gray-700 text-gray-700 bg-gray-200 rounded-md dark:gray-700 dark:text-gray-200 dark:hover:text-gray-200 dark:visited:text-gray-200">
@else
    <a href="{{ $href }}" class="flex items-center px-4 py-2 mt-5 visited:text-gray-600 text-gray-600 transition-colors duration-200 transform rounded-md dark:text-gray-400 hover:bg-gray-200 dark:hover:bg-gray-700 dark:hover:text-gray-200 hover:text-gray-700">
@endif
    {{ $icon }}
    <span class="mx-4 font-medium">{{ $slot }}</span>
</a>
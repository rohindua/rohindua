<textarea id="{{ $id }}"
    name="{{ $name }}"
    rows="{{ $rows }}"
    @if($form) form="{{ $form }}" @endif
    class="@if($attributes->has('class')){{ $attributes->get('class') }}@endif rounded-lg flex-1 appearance-none border border-gray-300 @error($name) border-red-500 @enderror w-full py-2 px-4 bg-white text-gray-700 placeholder-gray-400 shadow-sm text-base focus:outline-none focus:ring-2 focus:ring-purple-600 focus:border-transparent"
    @if($attributes->has('markdown')) data-markdown="1" @endif
    @if($errors->has($name)) placeholder="@error($name){{ $message }}@enderror"
    @else placeholder="{{ $placeholder }}" @endif
    @if($attributes->has('maxlength')) maxlength="{{ $attributes->get('maxlength') }}" @endif
    @if($attributes->has('required')) required="{{ $attributes->get('required') }}" @endif
    >{{ trim($slot) }}</textarea>
<div class="select-color-container w-full grid mb-4">
    <select
        name="{{ $name }}"
        id="{{ $id }}"
        @if($required) required="required" @endif
        {{ $attributes->merge(['class' => 'select-color no-search rounded-lg flex-1 appearance-none border border-gray-200 w-full py-3 px-4 bg-white text-gray-700 placeholder-gray-400 shadow-sm text-base focus:outline-none focus:ring-2 focus:ring-purple-600 focus:border-transparent']) }}
        >
        <option value="gray" data-color="gray" @if($selected == 'gray') selected="selected" @endif>{{ __('Gray') }}</option>
        <option value="red" data-color="red" @if($selected == null || $selected == 'red') selected="selected" @endif>{{ __('Red') }}</option>
        <option value="yellow" data-color="yellow" @if($selected == 'yellow') selected="selected" @endif>{{ __('Yellow') }}</option>
        <option value="green" data-color="green" @if($selected == 'green') selected="selected" @endif>{{ __('Green') }}</option>
        <option value="blue" data-color="blue" @if($selected == 'blue') selected="selected" @endif>{{ __('Blue') }}</option>
        <option value="indigo" data-color="indigo" @if($selected == 'indigo') selected="selected" @endif>{{ __('Indigo') }}</option>
        <option value="purple" data-color="purple" @if($selected == 'purple') selected="selected" @endif>{{ __('Purple') }}</option>
        <option value="pink" data-color="pink" @if($selected == 'pink') selected="selected" @endif>{{ __('Pink') }}</option>
        <option value="orange" data-color="orange" @if($selected == 'orange') selected="selected" @endif>{{ __('Orange') }}</option>
    </select>
</div>
<style>
    .select-color-container .select2-selection.select2-selection--single {
        --tw-border-opacity: 1;
        border-color: rgba(209, 213, 219, var(--tw-border-opacity));
        height: 42px;
        border-radius: 0.5rem;
    }
    .select-color-container .select2-selection.select2-selection--single > span {
        margin-top: .5rem;
        margin-left: .5rem;
    }
</style>
<div class="float-left">
    <div class="my-auto relative inline-block w-10 mr-2 align-middle select-none transition duration-200 ease-in">
        <input 
            type="checkbox" 
            @if($form) form="{{ $form }}" @endif
            @if($checked) checked="{{ $checked }}" @endif
            id="{{ $id }}" 
            name="{{ $name }}" 
            value="{{ $value }}" 
            class="focus:ring-0 focus:shadow-inner absolute border-gray-200 block w-6 h-6 rounded-full bg-white border-4 appearance-none cursor-pointer toggle-checkbox" >
        <label for="{{ $id }}" class="block overflow-hidden h-6 rounded-full bg-gray-300 cursor-pointer toggle-label"></label>
    </div>
    <label for="{{ $id }}" class="my-auto text-xs text-gray-700">{{ $label }}</label>
</div>
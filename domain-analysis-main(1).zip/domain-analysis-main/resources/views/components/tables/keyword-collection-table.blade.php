<table class="w-full divide-y divide-gray-200">
    <colgroup>
        <col class="w-1/3">
        <col class="w-2/3">
        @if(!$small)
        <col>
        @endif
    </colgroup>
    <thead class="bg-gray-50">
        <tr>
            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                {{ __('Name') }}
            </th>
            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                {{ __('Info') }}
            </th>
            @if(!$small)
            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider relative whitespace-nowrap">
                {{ __('Actions') }}
            </th>
            @endif
        </tr>
    </thead>
    <tbody class="bg-white divide-y divide-gray-200">
        @forelse ($collections as $collection)
            <tr>
                <td class="px-6 py-3 text-base font-bold text-gray-500">
                    <a href="/keywords/{{ $collection->id }}">{{ $collection->name }}</a>
                </td>
                <td class="px-6 py-3 text-sm text-gray-500">
                    <div class="flex gap-7">
                        <div class="flex align-center gap-2 whitespace-nowrap">
                            <x-icon type="tag" class="w-5 h-5" />
                            <span>{{ trans_choice(':count keyword|:count keywords', $collection->keywords_count) }}</span>
                        </div>
                    </div>
                </td>
                @if(!$small)
                <td class="px-6 py-3 whitespace-nowrap">
                    <x-action-link 
                        id="delete-collection-{{ $collection->id }}"
                        icon="delete"
                        color="red"
                        onclick="event.preventDefault();DomainAnalysis.openDeleteConfirmationModal({{ $collection->id }}, '#delete-collection-id', '#delete-collection-confirmation-modal');"
                        tooltip="{{ __('Delete collection') }}" />
                </td>
                @endif
            </tr>
        @empty
            <tr>
                <td @if(!$small) colspan="4" @else colspan="3" @endif class="px-6 py-4 text-sm text-gray-500">
                    <em>{{ __('No keyword collections found') }}</em>
                </td>
            </tr>
        @endforelse
    </tbody>
</table>
<x-confirmation-modal title="{{ __('Delete keyword collection') }}" id="delete-collection-confirmation-modal" method="POST" action="/keyword-collection/delete" oncancel="DomainAnalysis.closeDeleteConfirmationModal('#delete-collection-id', '#delete-collection-confirmation-modal')">
    {{ __('Are you sure you want to permanently delete this collection and all associated data?') }}
    <input type="hidden" id="delete-collection-id" name="collection-id" value="">
</x-confirmation-modal>
<x-form-modal title="{{ __('Edit keyword collection') }}" action="/keyword-collection/edit" method="POST" oncancel="DomainAnalysis.closeModal('#edit-collection-modal')" id="edit-collection-modal" icon="plus"></x-form-modal>
@if($collections)
    {{ $collections->links() }}
@endif
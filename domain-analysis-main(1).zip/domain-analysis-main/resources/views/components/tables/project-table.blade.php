<table class="w-full divide-y divide-gray-200">
    <colgroup>
        <col class="w-1/3">
        <col class="w-2/3">
        @if(!$small)
        <col>
        @endif
    </colgroup>
    <thead class="bg-gray-50">
        <tr>
            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                {{ __('Name') }}
            </th>
            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                {{ __('Info') }}
            </th>
            @if(!$small)
            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider relative whitespace-nowrap">
                {{ __('Actions') }}
            </th>
            @endif
        </tr>
    </thead>
    <tbody class="bg-white divide-y divide-gray-200">
        @forelse ($projects as $project)
            <tr>
                <td class="px-6 py-3 text-base font-bold text-gray-500">
                    <a href="/project/{{ $project->id }}">{{ $project->name }}</a>
                </td>
                <td class="px-6 py-3 text-sm text-gray-500">
                    <div class="flex gap-7">
                        <div class="flex align-center gap-2 whitespace-nowrap">
                            <x-icon type="link" class="w-5 h-5" />
                            <span>{{ trans_choice(':count domain|:count domains', $project->domains_count) }}</span>
                        </div>
                        <div class="flex align-center gap-2 whitespace-nowrap">
                            <x-icon type="camera" class="w-5 h-5" />
                            {{ trans_choice(':count screenshot|:count screenshots', $project->screenshots_count) }}
                        </div>
                    </div>
                </td>
                @if(!$small)
                <td class="px-6 py-3 whitespace-nowrap">
                    <x-action-link 
                        icon="edit"
                        id="edit-project-{{ $project->id }}"
                        color="gray"
                        onclick="event.preventDefault();DomainAnalysis.initEditProjectModal({{ $project->id }}, '#edit-project-modal');"
                        tooltip="{{ __('Edit') }}" />
                    <x-action-link 
                        id="delete-project-{{ $project->id }}"
                        icon="delete"
                        color="red"
                        onclick="event.preventDefault();DomainAnalysis.openDeleteConfirmationModal({{ $project->id }}, '#delete-project-id', '#delete-project-confirmation-modal');"
                        tooltip="{{ __('Delete project') }}" />
                </td>
                @endif
            </tr>
        @empty
            <tr>
                <td @if(!$small) colspan="4" @else colspan="3" @endif class="px-6 py-4 text-sm text-gray-500">
                    <em>{{ __('No projects found') }}</em>
                </td>
            </tr>
        @endforelse
    </tbody>
</table>
<x-confirmation-modal title="{{ __('Delete project') }}" id="delete-project-confirmation-modal" method="POST" action="/project/delete" oncancel="DomainAnalysis.closeDeleteConfirmationModal('#delete-project-id', '#delete-project-confirmation-modal')">
    {{ __('Are you sure you want to permanently delete this project and all associated data?') }}
    <input type="hidden" id="delete-project-id" name="project-id" value="">
</x-confirmation-modal>
<x-form-modal title="{{ __('Edit project') }}" action="/project/edit" method="POST" oncancel="DomainAnalysis.closeModal('#edit-project-modal')" id="edit-project-modal" icon="plus"></x-form-modal>
@if($projects)
    {{ $projects->links() }}
@endif
<table class="w-full divide-y divide-gray-200">
    <colgroup>
        <col class="w-full">
        <col>
    </colgroup>
    <thead class="bg-gray-50">
        <tr>
            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                {{ __('Keyword') }}
            </th>
            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider relative whitespace-nowrap">
                {{ __('Actions') }}
            </th>
        </tr>
    </thead>
    <tbody class="bg-white divide-y divide-gray-200">
        @forelse ($keywords as $keyword)
            <tr>
                <td class="px-6 py-3 text-base text-gray-500">
                    {{ strtolower($keyword->name) }}
                </td>
                <td class="px-6 py-3 whitespace-nowrap">
                    <x-action-link 
                        id="delete-keyword-{{ $keyword->id }}"
                        icon="delete"
                        color="red"
                        onclick="event.preventDefault();DomainAnalysis.openDeleteConfirmationModal({{ $keyword->id }}, '#delete-keyword-id', '#delete-keyword-confirmation-modal');"
                        tooltip="{{ __('Delete keyword') }}" />
                </td>
            </tr>
        @empty
            <tr>
                <td @if(!$small) colspan="2" @else colspan="3" @endif class="px-6 py-4 text-sm text-gray-500">
                    <em>{{ __('No keywords found') }}</em>
                </td>
            </tr>
        @endforelse
    </tbody>
</table>
<x-confirmation-modal title="{{ __('Delete keyword keyword') }}" id="delete-keyword-confirmation-modal" method="POST" action="/keyword/delete" oncancel="DomainAnalysis.closeDeleteConfirmationModal('#delete-keyword-id', '#delete-keyword-confirmation-modal')">
    {{ __('Are you sure you want to permanently delete this keyword and all associated data?') }}
    <input type="hidden" id="delete-keyword-id" name="keyword-id" value="">
</x-confirmation-modal>
@if($keywords)
    {{ $keywords->links() }}
@endif
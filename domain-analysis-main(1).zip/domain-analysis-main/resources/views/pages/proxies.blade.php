<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            {{ __('Proxies') }}
        </h2>
    </x-slot>

    <div class="max-w-100 mx-auto sm:px-6 lg:px-8">
        <div class="sm:py-6 space-y-6 lg:space-y-0 lg:grid lg:grid-flow-row gap-6 lg:grid-cols-8">
            <div class="bg-white shadow-xl sm:rounded-lg col-span-8">
                <form action="/proxies/save" method="POST" class="mx-7 my-6">
                    @csrf
                    <x-textarea name="proxies" 
                        id="proxies" 
                        rows="12" 
                        placeholder="{{ __('Enter a list of proxies here, one per line. Format: [ip]:[port]:[user]:[password]') }}"
                        >@foreach ($proxies as $proxy){{ $proxy->full_string . "\r\n" }}@endforeach</x-textarea>
                    <x-submit-button name="submit-proxies" id="submit-proxies" class="mt-4">{{ __('Save proxy list') }}</x-submit-button>
                </form>
            </div>
        </div>
    </div>
</x-app-layout>

<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <strong>{{ __('Project: ') }}</strong> {{ $project->name }}
        </h2>
        @if($project->description)
        <p class="text-gray-500">{{ $project->description }}</p>
        @endif
        <div class="mt-5 relative">
            <div class="relative w-full grid lg:grid-cols-4 gap-4">
                <form action="/project/run" method="post" class="flex content-center lg:col-span-3">
                    @csrf
                    <input type="hidden" name="id" value="{{ $project->id }}">
                    <span class="self-center text-gray-500 text-sm">{{ __('Starting year:') }}</span>
                    <select name="starting-year" class=" ml-1 rounded-lg appearance-none border border-gray-300 py-2 px-4 bg-white text-gray-700 placeholder-gray-400 shadow-sm focus:outline-none focus:ring-2 focus:ring-purple-600 focus:border-transparent">
                        @for($i = 2001; $i < date('Y'); $i++)
                            <option value="{{ $i }}" {{ $i == (intval(date('Y')) - 10) ? 'selected="selected"' : '' }}>{{ $i }}&nbsp;&nbsp;&nbsp;</option>
                        @endfor
                    </select>
                    <select name="period" class="ml-4 rounded-lg appearance-none border border-gray-300 py-2 px-4 bg-white text-gray-700 placeholder-gray-400 shadow-sm focus:outline-none focus:ring-2 focus:ring-purple-600 focus:border-transparent">
                        <option value="-1">{{ __('Just once') }}&nbsp;&nbsp;</option>
                        <option value="1">{{ __('Every month') }}&nbsp;&nbsp;</option>
                        <option value="2">{{ __('Every two months') }}&nbsp;&nbsp;</option>
                        <option value="3">{{ __('Every three months') }}&nbsp;&nbsp;</option>
                        <option value="6" selected="selected">{{ __('Every six months') }}&nbsp;&nbsp;</option>
                        <option value="12">{{ __('Every twelve months') }}&nbsp;&nbsp;</option>
                    </select>
                    <select name="scraper" class=" ml-1 rounded-lg appearance-none border border-gray-300 py-2 px-4 pr-8 bg-white text-gray-700 placeholder-gray-400 shadow-sm focus:outline-none focus:ring-2 focus:ring-purple-600 focus:border-transparent">
                        <option value="0">{{ __('Site-shot') }}</option>
                        <option value="1" selected="selected">{{ __('One Simple API') }}</option>
                        <option value="2">{{ __('Thrum') }}</option>
                    </select>
                    <button 
                        type="submit" 
                        class="ml-4 bg-indigo-600 border border-indigo-600 hover:bg-indigo-700 hover:border-indigo-700 text-base text-white font-bold py-2 px-3 rounded-lg inline-flex items-center disabled:opacity-50"
                        @if($project->is_processing || $project->needs_processing) disabled="disabled" @endif >
                        @if($project->is_processing || $project->needs_processing)
                            <x-icon type="clock" class="h-5 w-5 inline-block mr-2" />
                        @else
                            <x-icon type="camera" class="h-5 w-5 inline-block mr-2" />
                        @endif
                        <span>
                            @if($project->is_processing)
                                {{ __('Currently processing') }}
                            @elseif($project->needs_processing)
                                {{ __('Processing scheduled') }}
                            @else
                                {{ __('Start processing') }}
                            @endif
                        </span>
                    </button>
                    <span class="ml-2 self-center text-gray-500 text-sm">{{ __('or') }}</span>
                    <button class="ml-2 bg-indigo-600 hover:bg-indigo-700 hover:text-white text-base text-white font-bold py-2 px-3 rounded-lg inline-flex items-center" name="export" value="yes" type="submit">
                        <x-icon type="document-download" class="h-4 w-4 inline-block mr-2"></x-icon>
                        <span>{{ __('Export to CSV') }}</span>
                    </button>
                </form>
                <div class="flex align-center gap-4 justify-end">
                    <button onclick="DomainAnalysis.openModal('#add-domains-modal')" class="bg-green-400 hover:bg-green-500 text-base text-white font-bold py-2 px-3 rounded-lg inline-flex items-center">
                        <x-icon type="plus" class="h-4 w-4 inline-block mr-2"></x-icon>
                        <span>{{ __('Add domains') }}</span>
                    </button>
                </div>
            </div>
        </div>
    </x-slot>
    <div class="max-w-100 mx-auto sm:px-6 lg:px-8">
        <div class="sm:py-6 space-y-6 lg:space-y-0 lg:grid lg:grid-flow-row gap-6 lg:grid-cols-8">
            <div class="bg-white shadow-xl sm:rounded-lg col-span-8">
                <form action="" method="get" class="flex gap-4 align-center mt-4 mx-4 xl:col-span-2">
                    <x-text-input name="q" value="{{ request()->get('q') }}" id="q" placeholder="{{ __('Search for domain') }}" maxlength=255 />
                    <button 
                        type="submit" 
                        class="bg-indigo-600 border border-indigo-600 hover:bg-indigo-700 hover:border-indigo-700 text-base text-white font-bold py-2 px-3 rounded-lg inline-flex items-center disabled:opacity-50">
                        <x-icon type="search" class="h-5 w-5 inline-block mr-2" />
                        <span>{{ __('Search') }}</span>
                    </button>
                </form>
                <x-domain-list title="{{ __('Domains') }}" :domains="$domains" />
            </div>
        </div>
    </div>
    <x-form-modal title="{{ __('Add domains') }}" action="/project/{{ $project->id }}/add" method="POST" oncancel="DomainAnalysis.closeModal('#add-domains-modal')" id="add-domains-modal" icon="plus">
        <x-add-domain-form-fields />
    </x-form-modal>
</x-app-layout>

<x-app-layout>
    <x-slot name="header">
        <div class="relative w-full">
            <div class="absolute right-2 top-1/2 -translate-y-1/2">
                <button onclick="DomainAnalysis.openModal('#new-project-modal')" class="bg-indigo-600 hover:bg-indigo-700 text-base text-white font-bold py-2 px-3 rounded inline-flex items-center">
                    <x-icon type="plus" class="h-4 w-4 inline-block mr-2"></x-icon>
                    <span>{{ __('New project') }}</span>
                </button>
            </div>
            <h2 class="font-semibold text-xl text-gray-800 leading-tight">
                {{ __('Dashboard') }}
            </h2>
        </div>
    </x-slot>
    <div class="max-w-100 mx-auto sm:px-6 lg:px-8">
        <div class="sm:py-6 space-y-6 lg:space-y-0 lg:grid lg:grid-flow-row gap-6 lg:grid-cols-8">
            <div class="bg-white shadow-xl sm:rounded-lg col-span-8">
                <x-project-list :projects="$projects" title="{{ __('Projects') }}" />
            </div>
        </div>
    </div>
    <x-form-modal title="{{ __('Create new project') }}" action="/project/new" method="POST" oncancel="DomainAnalysis.closeModal('#new-project-modal')" id="new-project-modal" icon="plus">
        <x-project-form-fields :projects="$projects" />
    </x-form-modal>
</x-app-layout>

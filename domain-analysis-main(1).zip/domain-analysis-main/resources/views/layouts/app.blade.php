<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="{{ csrf_token() }}">

        <title>{{ config('app.name', __('Domain Analysis')) }}</title>

        <link rel="shortcut icon" href="/favicon.ico">

        <!-- Fonts -->
        <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap">

        <!-- Styles -->
        <link rel="stylesheet" href="{{ mix('css/app.css') }}">

        @livewireStyles

        <!-- Scripts -->
        <script id="critical-js" src="{{ mix('js/critical.js') }}"></script>
        <script id="app-js" src="{{ mix('js/app.js') }}" defer></script>
    </head>
    <body class="font-sans antialiased min-h-screen flex flex-col">
        <x-jet-banner />

        <div class="bg-gray-100 w-100">
            @livewire('navigation-menu')
        </div>

        <div class="bg-gray-100 flex flex-row flex-grow">
            <x-side-bar />

            <div class="flex flex-col w-full md:space-y-4">
                <!-- Page Heading -->
                @if (isset($header))
                    <header class="bg-white shadow">
                        <div class="w-full mx-auto py-6 px-4 sm:px-6 lg:px-8">
                            {{ $header }}
                        </div>
                    </header>
                @endif

                <!-- Page Content -->
                <main>
                    {{ $slot }}
                </main>
            </div>
        </div>

        @stack('modals')

        @livewireScripts
    </body>
</html>

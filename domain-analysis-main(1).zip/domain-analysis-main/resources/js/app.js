require('./polyfill');
require('./bootstrap');
require ('featherlight');

import Alpine from 'alpinejs';

window.Alpine = Alpine;

Alpine.start();

import DomainAnalysis from './domain-analysis';

window.DomainAnalysis = DomainAnalysis;

DomainAnalysis.start();
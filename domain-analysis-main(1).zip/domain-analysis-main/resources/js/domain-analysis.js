import 'jquery-zoom';

class DomainAnalysis {
    start() {
        this.initClickEvents();
        this.initChangeEvents();
        this.initSelects();
    }

    initClickEvents() {
        $('.modal-bg').on('click', function() {
            let selector = $(this).attr('data-modal-selector');
            $(selector).addClass('hidden');
        });
    }

    initChangeEvents() {
        $('input[type="checkbox"].group-parent').on('change', {adm: this}, function(e) {
            let checked = $(this).prop('checked');
            let group = $(this).attr('data-group');
            let type = $('input[type="checkbox"][data-group="' + group + '"].grouped').attr('data-type');
            $('input[type="checkbox"][data-group="' + group + '"].grouped').prop('checked', checked);
            e.data.adm.setSelectedCountValue(type);
        });
    
        $('input[type="checkbox"].grouped').on('change', {adm: this}, function(e) {
            let group = $(this).attr('data-group');
            let type = $(this).attr('data-type');
            let allChecked = true, someChecked = false;
            $('input[type="checkbox"][data-group="' + group + '"].grouped').each(function() {
                if($(this).prop('checked')) someChecked = true;
                else allChecked = false;
            });
            $('input[type="checkbox"][data-group="' + group + '"].group-parent').prop({
                indeterminate: !allChecked && someChecked,
                checked: allChecked,
            });
            e.data.adm.setSelectedCountValue(type)
        })
    }

    initSelects() {
        $('.select-color').select2({
            dropdownCssClass: 'no-search',
            minimumResultsForSearch: -1,
            templateResult: this.addColorBox,
            templateSelection: this.addColorBox,
        });
    }

    loadImageZoom() {
        $('.featherlight-image')
            .wrap('<div class="image-zoom-container" style="display:inline-block;width:800px;height:535px"></div>')
            .css('display', 'block')
            .parent()
            .zoom({
                magnify: 1,
            });
    }

    openDeleteConfirmationModal(id, idSelector, modalSelector) {
        $(idSelector).val(id);
        this.openModal(modalSelector);
    }

    closeDeleteConfirmationModal(idSelector, modalSelector) {
        $(idSelector).val('');
        this.openModal(modalSelector);
    }

    openModal(modalSelector) {
        this.showElement(modalSelector);
    }

    closeModal(modalSelector, removeContent = false) {
        this.hideElement(modalSelector);
        if(removeContent) {
            $(modalSelector + ' .modal-content').html('');
        }
    }

    initEditModal(modalSelector, apiUrl) {
        this.hideElement(modalSelector + ' .modal-icon');
        this.showElement(modalSelector + ' .modal-spinner');
        this.showElement(modalSelector);
        let d = this;

        $.ajax({
            url: apiUrl,
            method: 'GET',
            success: function(data) {
                d.hideElement(modalSelector + ' .modal-spinner');
                d.showElement(modalSelector + ' .modal-icon');
                $(modalSelector + ' .modal-content').html(data);
            },
        });
    }

    initEditProjectModal(id, modalSelector) {
        this.initEditModal(modalSelector, '/project/' + id + '/form');
    }

    showElement(selector) {
        $(selector).removeClass('hidden');
    }

    hideElement(selector) {
        $(selector).addClass('hidden');
    }

    addColorBox(opt) {
        let color = $(opt.element).data('color');
        if(!color) {
            return opt.text;
        }
        return $('<span class="flex items-stretch"><div class="w-3 h-3 rounded-lg mr-2 inline-block self-center bg-' + color + '-300"></div> ' + opt.text + '</span>');
    }
}

export default new DomainAnalysis();
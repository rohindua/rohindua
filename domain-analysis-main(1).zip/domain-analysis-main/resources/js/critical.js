window.jQuery = window.$ = require('jquery');
require('select2');

import LazyLoad from 'vanilla-lazyload';
window.lazyLoadInstance = new LazyLoad({
    use_native: true,
});
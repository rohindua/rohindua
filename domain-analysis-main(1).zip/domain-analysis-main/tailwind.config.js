const defaultTheme = require('tailwindcss/defaultTheme');
const colors = require('tailwindcss/colors');

module.exports = {
    mode: 'jit',
    purge: {
        content: [
            './vendor/laravel/framework/src/Illuminate/Pagination/resources/views/*.blade.php',
            './vendor/laravel/jetstream/**/*.blade.php',
            './storage/framework/views/*.php',
            './resources/views/**/*.blade.php',
        ],
        safelist: [
            'bg-gray-100', 'bg-red-100', 'bg-yellow-100', 'bg-green-100', 'bg-blue-100', 'bg-indigo-100', 'bg-purple-100', 'bg-pink-100', 'bg-orange-100',
            'bg-gray-200', 'bg-red-200', 'bg-yellow-200', 'bg-green-200', 'bg-blue-200', 'bg-indigo-200', 'bg-purple-200', 'bg-pink-200', 'bg-orange-200',
            'bg-gray-300', 'bg-red-300', 'bg-yellow-300', 'bg-green-300', 'bg-blue-300', 'bg-indigo-300', 'bg-purple-300', 'bg-pink-300', 'bg-orange-300',
            'hover:bg-gray-300', 'hover:bg-red-300', 'hover:bg-yellow-300', 'hover:bg-green-300', 'hover:bg-blue-300', 'hover:bg-indigo-300', 'hover:bg-purple-300', 'hover:bg-pink-300', 'hover:bg-orange-300', 
            'focus:ring-gray-300', 'focus:ring-red-300', 'focus:ring-yellow-300', 'focus:ring-green-300', 'focus:ring-blue-300', 'focus:ring-indigo-300', 'focus:ring-purple-300', 'focus:ring-pink-300', 'focus:ring-orange-300',
            'focus:ring-offset-gray-100', 'focus:ring-offset-red-100', 'focus:ring-offset-yellow-100', 'focus:ring-offset-green-100', 'focus:ring-offset-blue-100', 'focus:ring-offset-indigo-100', 'focus:ring-offset-purple-100', 'focus:ring-offset-pink-100', 'focus:ring-offset-orange-100', 
            'text-gray-300', 'text-red-300', 'text-yellow-300', 'text-green-300', 'text-blue-300', 'text-indigo-300', 'text-purple-300', 'text-pink-300', 'text-orange-300',
            'visited:text-gray-300', 'visited:text-red-300', 'visited:text-yellow-300', 'visited:text-green-300', 'visited:text-blue-300', 'visited:text-indigo-300', 'visited:text-purple-300', 'visited:text-pink-300', 'visited:text-orange-300',
            'hover:text-gray-500', 'hover:text-red-500', 'hover:text-yellow-500', 'hover:text-green-500', 'hover:text-blue-500', 'hover:text-indigo-500', 'hover:text-purple-500', 'hover:text-pink-500', 'hover:text-orange-500',
            'w-3', 'h-3', 'rounded', 'mr-2', 'self-center', 'items-stretch'
        ],
    },

    theme: {
        extend: {
            fontFamily: {
                sans: ['Nunito', ...defaultTheme.fontFamily.sans],
            },
            colors: {
                orange: colors.orange,
            },
            maxHeight: {
                '1/4': '25%',
                '1/2': '50%',
                '3/4': '75%',
            },
        },
    },

    plugins: [
        require('@tailwindcss/forms'), 
        require('@tailwindcss/typography'),
        require('tailwindcss-opentype'),
    ],
};

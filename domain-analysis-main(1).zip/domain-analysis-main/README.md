# Domain Analysis tool

The tool is written with [Laravel 8](https://laravel.com/docs/8.x).

### Minimum requirements
- PHP 8.0
- PHP modules: BCMath, Ctype, JSON, Mbstring, OpenSSL, PDO, Tokenizer, and XML
- PHP CLI
- Compatible database


### Installation
First, create an .env file and change the settings therein.
```
cp .env.example .env
nano .env
```

Next, install dependencies
```
composer install
```

Then run the database migrations
```
php artisan migrate
```

Development only: install NPM dependencies
```
npm install
```

Development only: after making changes to the CSS or Javascript, make sure to compile them
```
npm run prod
```
